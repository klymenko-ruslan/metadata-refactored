<?php
/**
 * @copyright   Copyright (c) 2009-2012 Amasty (http://www.amasty.com)
 */ 
class Amasty_Finder_Helper_Data extends Mage_Core_Helper_Abstract
{
    const SORT_STRING_ASC  = 0;
    const SORT_STRING_DESC = 1;
    const SORT_NUM_ASC     = 2;
    const SORT_NUM_DESC    = 3;
    
}