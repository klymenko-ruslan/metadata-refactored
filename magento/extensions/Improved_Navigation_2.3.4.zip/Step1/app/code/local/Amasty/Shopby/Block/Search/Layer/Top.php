<?php
class Amasty_Shopby_Block_Search_Layer_Top extends Amasty_Shopby_Block_Search_Layer
{
    protected $_blockPos     = 'top'; 
     
}